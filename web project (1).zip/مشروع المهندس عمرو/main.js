function login(){

    let username =
    document.getElementById("username").value;

    let password =
    document.getElementById("password").value;

    if(username === "admin"
    && password === "1234"){

        window.location.href =
        "home.html";
    }

    else{

        alert("Wrong Username Or Password");
    }
}
function addPatient(){

    let name =
    document.getElementById("name").value;

    let age =
    document.getElementById("age").value;

    let disease =
    document.getElementById("disease").value;

    let patient = {

        name: name,

        age: age,

        disease: disease
    };

    localStorage.setItem(
        "patient",
        JSON.stringify(patient)
    );

    alert("Patient Added Successfully");
}
function deletePatient(){

    localStorage.removeItem("patient");

    alert("Patient Deleted Successfully");
}
function updatePatient(){

    let name =
    document.getElementById("newName").value;

    let age =
    document.getElementById("newAge").value;

    let disease =
    document.getElementById("newDisease").value;

    let updatedPatient = {

        name: name,

        age: age,

        disease: disease
    };

    localStorage.setItem(
        "patient",
        JSON.stringify(updatedPatient)
    );

    alert("Patient Updated Successfully");
}
function viewPatient(){

    let data =
    localStorage.getItem("patient");

    let show =
    document.getElementById("showData");

    if(data){

        let patient =
        JSON.parse(data);

        show.innerHTML =
        "Name: " + patient.name +
        "<br>Age: " + patient.age +
        "<br>Disease: " + patient.disease;
    }

    else{

        show.innerHTML =
        "No Patient Found";
    }
}
function searchPatient(){

    let searchName =
    document.getElementById("searchName").value;

    let data =
    localStorage.getItem("patient");

    let result =
    document.getElementById("searchResult");

    if(data){

        let patient =
        JSON.parse(data);

        if(patient.name === searchName){

            result.innerHTML =
            "✅ Found Patient <br>" +
            "Name: " + patient.name +
            "<br>Age: " + patient.age +
            "<br>Disease: " + patient.disease;
        }

        else{

            result.innerHTML =
            "❌ Patient Not Found";
        }
    }

    else{

        result.innerHTML =
        "❌ No Data Available";
    }
}